import requests
import time
import json
import os
import webbrowser
from datetime import datetime, date, time as dtime, timezone, timedelta
from kiteconnect import KiteConnect

"""
SENSEX Scanner V1.0
- Monitors BSE SENSEX index options (BFO exchange)
- Scans underlying every 60s (1m cadence)
- Generates signals from structure flip, trendline break, early reversal, ORB, S/R rejection
- Sends PREMIUM Telegram alerts with T1..T5, SL, timestamp, OI build %, score, reason
- Sends up to 2 strikes per side when a signal occurs: ATM and 1-step OTM
- De-duplicates by (expiry, side, strike, reason) per day
- 3-minute candle tracking for reversal detection
"""

# =====================================================
# CONFIG (Intraday Momentum Preset for SENSEX)
# =====================================================
SYMBOL = "SENSEX"
INTERVAL_SEC = 60  # 1-minute checks
TEST_ALERT = False

# Offsets to alert when a signal occurs (0=ATM, 1=±100 OTM for Sensex). We will send at most these two per side.
ALERT_OFFSETS = [0, 1]

# Early PA reversal threshold (% on underlying)
PA_MIN_MOVE_PCT = 0.05
TRENDLINE_TOL_PCT = 0.05

# S/R Rejection detection parameters (scaled for Sensex ~3x Nifty value)
REJECTION_WICK_RATIO = 2.0  # Wick should be 2x the body for rejection candle
SR_ZONE_TOLERANCE_PTS = 50  # Points tolerance for S/R zone detection (Sensex trades at ~3x Nifty)
MIN_REJECTION_MOVE_PTS = 30  # Minimum move from S/R level to confirm rejection

# Opposite signal cooldown (prevents PE->CE or CE->PE whipsaw in sideways markets)
OPPOSITE_SIGNAL_COOLDOWN_SEC = 600  # 10 minutes cooldown before opposite direction signal
SAME_DIRECTION_COOLDOWN_SEC = 300   # 5 minutes cooldown for same direction signals

# Dominant trend tracking — prevents counter-trend signals
DOMINANT_TREND_LOOKBACK = 15  # Number of price samples to determine dominant trend
DOMINANT_TREND_MIN_MOVE_PCT = 0.10  # Min % move over lookback to establish dominant trend
MIN_SCORE_TO_SEND = 55  # Don't send signals below this score

# --- Intraday Momentum target/SL model ---
ENTRY_LOW_PCT = 0.98
ENTRY_HIGH_PCT = 1.02
# Risk:Reward based targets - T1=1R, T2=1.5R, T3=2.5R, T4=3.5R, T5=5R
# SL is 15% below entry, targets are multiples of risk
SL_PCT = 0.15  # 15% SL
TARGET_RR_MULTIPLIERS = [1.0, 1.5, 2.5, 3.5, 5.0]  # R:R ratios for T1-T5

# Supertrend parameters (tuned for 1-min polling: shorter period, tighter multiplier)
SUPERTREND_PERIOD = 7
SUPERTREND_MULTIPLIER = 1.5

# Premium & filters
PREMIUM_FORMAT_ENABLED = True
OI_FILTER_ENABLED = False
OI_MIN_BUILD_PCT = 1.0

# Trading
ORDER_QUANTITY_LOTS = 1
ORDER_TYPE = "MARKET"  # or "LIMIT"
PRODUCT_TYPE = "MIS"

# Telegram confirm
CONFIRM_TIMEOUT_SEC = 60
SEMI_AUTO_ENABLED = True

# Credentials
ENV_FILE_PATH = r"E:\\Trading Scripts\\Python Script\\Project\\Project Zerodha_Latest_2\\.env"
CALLBACK_SERVER_URL = "http://localhost:8000"

# ---------- ENV ----------
def load_env_file(env_path):
    env_vars = {}
    if not os.path.exists(env_path):
        print(f"WARNING: .env not found at {env_path}")
        return env_vars
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, _, v = line.partition('=')
            env_vars[k.strip()] = v.strip()
    return env_vars

_env = load_env_file(ENV_FILE_PATH)
KITE_API_KEY = _env.get("KITE_API_KEY", "")
KITE_API_SECRET = _env.get("KITE_API_SECRET", "")
TELEGRAM_BOT_TOKEN = _env.get("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = _env.get("TELEGRAM_CHAT_ID", "")
if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
    print("WARNING: Telegram bot token or chat id is empty; alerts will not be sent")
else:
    print(f"Telegram configured (chat_id={TELEGRAM_CHAT_ID})")

# Globals
kite = None
bfo_instruments = []  # BSE F&O instruments
sensex_lot_size = 10  # Default Sensex lot size

IST = timezone(timedelta(hours=5, minutes=30))

def fmt_ist_now():
    return datetime.now(IST).strftime("%d-%b-%Y %H:%M:%S")

# ---------- Login ----------
def kite_login():
    global kite
    kite = KiteConnect(api_key=KITE_API_KEY)
    saved = _env.get("KITE_ACCESS_TOKEN", "")
    if saved:
        try:
            kite.set_access_token(saved)
            profile = kite.profile()
            print(f"Kite: token OK — Logged in as {profile['user_name']} ({profile['user_id']})")
            return
        except Exception:
            print("Saved token invalid/expired; proceeding to browser login…")
    url = kite.login_url()
    webbrowser.open(url)
    print("Waiting for login via callback server…")
    for i in range(90):
        time.sleep(2)
        try:
            r = requests.get(f"{CALLBACK_SERVER_URL}/api/auth/status", timeout=5)
            if r.json().get('connected'):
                break
        except Exception:
            pass
        if i % 5 == 0:
            print(f"  …still waiting ({i*2}s)")
    fresh = load_env_file(ENV_FILE_PATH)
    token = fresh.get("KITE_ACCESS_TOKEN", "")
    kite.set_access_token(token)
    profile = kite.profile()
    print(f"Kite: login complete — {profile['user_name']} ({profile['user_id']})")

# ---------- Instruments ----------
from datetime import date as _date

def load_sensex_instruments():
    """Load SENSEX options from BFO (BSE F&O) exchange"""
    global bfo_instruments, sensex_lot_size
    try:
        all_bfo = kite.instruments("BFO")
        bfo_instruments = [i for i in all_bfo if i['name'] == "SENSEX" and i['instrument_type'] in ("CE", "PE")]
        if bfo_instruments:
            sensex_lot_size = bfo_instruments[0]['lot_size']
            expiries = sorted(set(i['expiry'] for i in bfo_instruments))
            print(f"Loaded {len(bfo_instruments)} SENSEX options across {len(expiries)} expiries. Lot size: {sensex_lot_size}")
        else:
            print("WARNING: No SENSEX options found in BFO exchange")
    except Exception as e:
        print(f"Error loading BFO instruments: {e}")


def get_current_week_expiry():
    today = _date.today()
    expiries = sorted(set(i['expiry'] for i in bfo_instruments))
    for e in expiries:
        if e >= today:
            return e
    return None

# ---------- Helpers ----------

def within_market_time():
    now = datetime.now().time()
    return dtime(9,15) <= now <= dtime(15,30)

def nearest_100(x):
    """Round to nearest 100 (Sensex strike interval)"""
    return int(round(x/100.0)*100)


def find_instruments_for_offsets(spot, expiry, offsets):
    """Return dict: {'CE': {0: inst, 1: inst}, 'PE': {0: inst, 1: inst}} for given offsets list
    For Sensex, strike interval is 100 points
    """
    base = nearest_100(spot)
    ce_map = {}
    pe_map = {}
    for inst in bfo_instruments:
        if inst['expiry'] != expiry:
            continue
        if inst['instrument_type'] == 'CE':
            for off in offsets:
                if inst['strike'] == base + off * 100:  # 100-point strike interval for Sensex
                    ce_map[off] = inst
        elif inst['instrument_type'] == 'PE':
            for off in offsets:
                if inst['strike'] == base - off * 100:  # 100-point strike interval for Sensex
                    pe_map[off] = inst
    return {'CE': ce_map, 'PE': pe_map}


def fetch_all_quotes(ce_dict, pe_dict):
    """Fetch quotes for BFO instruments"""
    keys = []
    for off, inst in ce_dict.items():
        keys.append(f"BFO:{inst['tradingsymbol']}")
    for off, inst in pe_dict.items():
        keys.append(f"BFO:{inst['tradingsymbol']}")
    quotes = {}
    if not keys:
        return quotes
    try:
        data = kite.quote(keys)
        for k, v in data.items():
            quotes[k] = {
                'ltp': v.get('last_price'),
                'oi': v.get('oi')
            }
    except Exception as e:
        print("kite.quote error:", e)
    return quotes

# ---------- OI % helpers ----------

def calc_oi_change_pct(cur, prev):
    if prev in (None, 0) or cur is None:
        return None
    return ((cur - prev) / prev) * 100.0


# ---------- OHLC Candle Tracking ----------

class CandleTracker:
    """Track OHLC data for candle pattern detection"""
    def __init__(self, interval_minutes=1):
        self.interval = interval_minutes
        self.candles = []  # List of {open, high, low, close, time}
        self.current_candle = None
        self.last_candle_minute = None
    
    def _get_candle_boundary(self, timestamp):
        """Get the start time of the candle boundary for given timestamp"""
        minute = timestamp.replace(second=0, microsecond=0)
        # Align to interval boundaries (e.g., 3-min: 09:15, 09:18, 09:21...)
        total_minutes = minute.hour * 60 + minute.minute
        boundary_minute = (total_minutes // self.interval) * self.interval
        return minute.replace(hour=boundary_minute // 60, minute=boundary_minute % 60)

    def update(self, price, timestamp=None):
        """Update with new price tick"""
        if timestamp is None:
            timestamp = datetime.now()
        
        candle_boundary = self._get_candle_boundary(timestamp)
        
        # Start new candle if boundary changed
        if self.last_candle_minute is None or candle_boundary > self.last_candle_minute:
            # Save completed candle
            if self.current_candle is not None:
                self.candles.append(self.current_candle)
                if len(self.candles) > 100:  # Keep last 100 candles
                    self.candles.pop(0)
            
            # Start new candle
            self.current_candle = {
                'open': price,
                'high': price,
                'low': price,
                'close': price,
                'time': candle_boundary
            }
            self.last_candle_minute = candle_boundary
        else:
            # Update current candle
            if self.current_candle:
                self.current_candle['high'] = max(self.current_candle['high'], price)
                self.current_candle['low'] = min(self.current_candle['low'], price)
                self.current_candle['close'] = price
    
    def get_last_n_candles(self, n):
        """Get last n completed candles"""
        return self.candles[-n:] if len(self.candles) >= n else self.candles
    
    def get_session_high_low(self):
        """Get session high and low from all candles"""
        if not self.candles:
            return None, None
        session_high = max(c['high'] for c in self.candles)
        session_low = min(c['low'] for c in self.candles)
        return session_high, session_low


# ---------- S/R Level Detection ----------

class SRLevelTracker:
    """Track and manage dynamic Support/Resistance levels"""
    def __init__(self):
        self.levels = []  # List of {price, type: 'support'/'resistance', strength, touches}
        self.session_high = None
        self.session_low = None
    
    def update_session_levels(self, high, low):
        """Update session high/low"""
        self.session_high = high
        self.session_low = low
    
    def add_level(self, price, level_type, strength=1):
        """Add a new S/R level"""
        # Check if level already exists nearby
        for lvl in self.levels:
            if abs(lvl['price'] - price) < SR_ZONE_TOLERANCE_PTS:
                lvl['touches'] += 1
                lvl['strength'] = min(5, lvl['strength'] + 1)
                return
        self.levels.append({'price': price, 'type': level_type, 'strength': strength, 'touches': 1})
        # Keep max 10 levels
        if len(self.levels) > 10:
            self.levels.sort(key=lambda x: x['strength'], reverse=True)
            self.levels = self.levels[:10]
    
    def get_nearest_resistance(self, current_price):
        """Get nearest resistance above current price"""
        resistances = [l for l in self.levels if l['type'] == 'resistance' and l['price'] > current_price]
        if self.session_high and self.session_high > current_price:
            resistances.append({'price': self.session_high, 'type': 'resistance', 'strength': 3, 'touches': 1})
        if not resistances:
            return None
        return min(resistances, key=lambda x: x['price'])
    
    def get_nearest_support(self, current_price):
        """Get nearest support below current price"""
        supports = [l for l in self.levels if l['type'] == 'support' and l['price'] < current_price]
        if self.session_low and self.session_low < current_price:
            supports.append({'price': self.session_low, 'type': 'support', 'strength': 3, 'touches': 1})
        if not supports:
            return None
        return max(supports, key=lambda x: x['price'])
    
    def is_near_resistance(self, price, tolerance=SR_ZONE_TOLERANCE_PTS):
        """Check if price is near any resistance level"""
        for lvl in self.levels:
            if lvl['type'] == 'resistance' and abs(price - lvl['price']) <= tolerance:
                return True, lvl['price']
        if self.session_high and abs(price - self.session_high) <= tolerance:
            return True, self.session_high
        return False, None
    
    def is_near_support(self, price, tolerance=SR_ZONE_TOLERANCE_PTS):
        """Check if price is near any support level"""
        for lvl in self.levels:
            if lvl['type'] == 'support' and abs(price - lvl['price']) <= tolerance:
                return True, lvl['price']
        if self.session_low and abs(price - self.session_low) <= tolerance:
            return True, self.session_low
        return False, None


# ---------- Rejection Pattern Detection ----------

def detect_rejection_candle(candle):
    """Detect if candle is a rejection/pin bar pattern
    Returns: ('bullish_rejection', 'bearish_rejection', or None), wick_size
    """
    if not candle:
        return None, 0
    
    o, h, l, c = candle['open'], candle['high'], candle['low'], candle['close']
    body = abs(c - o)
    upper_wick = h - max(o, c)
    lower_wick = min(o, c) - l
    total_range = h - l
    
    if total_range < 1:  # Avoid division by zero
        return None, 0
    
    # Bullish rejection (hammer): long lower wick, small body, price near high
    if lower_wick > body * REJECTION_WICK_RATIO and lower_wick > upper_wick * 1.5:
        return 'bullish_rejection', lower_wick
    
    # Bearish rejection (shooting star): long upper wick, small body, price near low
    if upper_wick > body * REJECTION_WICK_RATIO and upper_wick > lower_wick * 1.5:
        return 'bearish_rejection', upper_wick
    
    return None, 0


def detect_reversal_confirmation(candles, direction):
    """Check if last 2-3 candles confirm a reversal
    direction: 'bullish' or 'bearish'
    Returns: True if confirmed, False otherwise
    """
    if len(candles) < 2:
        return False
    
    last = candles[-1]
    prev = candles[-2]
    
    if direction == 'bullish':
        # Bullish reversal: current close > previous close, current close > current open
        if last['close'] > prev['close'] and last['close'] > last['open']:
            return True
        # Or: current low > previous low (higher low formation)
        if last['low'] > prev['low']:
            return True
    
    elif direction == 'bearish':
        # Bearish reversal: current close < previous close, current close < current open
        if last['close'] < prev['close'] and last['close'] < last['open']:
            return True
        # Or: current high < previous high (lower high formation)
        if last['high'] < prev['high']:
            return True
    
    return False


def check_sr_rejection(candle_tracker, sr_tracker, current_price, orb_high, orb_low):
    """Main function to check for S/R rejection signals
    Returns: (signal_type, reason, sr_level) or (None, None, None)
    """
    candles = candle_tracker.get_last_n_candles(5)
    if len(candles) < 2:
        return None, None, None
    
    last_candle = candles[-1]
    prev_candle = candles[-2]
    
    # Get session high/low
    session_high, session_low = candle_tracker.get_session_high_low()
    if session_high:
        sr_tracker.update_session_levels(session_high, session_low)
    
    # Add ORB levels as S/R
    if orb_high:
        sr_tracker.add_level(orb_high, 'resistance', strength=2)
    if orb_low:
        sr_tracker.add_level(orb_low, 'support', strength=2)
    
    # Check for rejection patterns
    rejection_type, wick_size = detect_rejection_candle(last_candle)
    
    # RESISTANCE REJECTION (Bearish signal -> Buy PE)
    if rejection_type == 'bearish_rejection' or (last_candle['high'] > prev_candle['high'] and last_candle['close'] < last_candle['open']):
        # Check if rejection happened near resistance
        near_res, res_level = sr_tracker.is_near_resistance(last_candle['high'])
        near_orb_high = orb_high and abs(last_candle['high'] - orb_high) <= SR_ZONE_TOLERANCE_PTS
        near_session_high = session_high and abs(last_candle['high'] - session_high) <= SR_ZONE_TOLERANCE_PTS
        
        if near_orb_high:
            move_from_high = last_candle['high'] - current_price
            if move_from_high >= MIN_REJECTION_MOVE_PTS:
                return 'bearish', f"ORB High Rejection at {orb_high:.0f} (Pin Bar)", orb_high
        
        if near_session_high:
            move_from_high = last_candle['high'] - current_price
            if move_from_high >= MIN_REJECTION_MOVE_PTS:
                return 'bearish', f"Session High Rejection at {session_high:.0f}", session_high
        
        if near_res:
            move_from_high = last_candle['high'] - current_price
            if move_from_high >= MIN_REJECTION_MOVE_PTS:
                return 'bearish', f"Resistance Rejection at {res_level:.0f}", res_level
    
    # SUPPORT REJECTION (Bullish signal -> Buy CE)
    if rejection_type == 'bullish_rejection' or (last_candle['low'] < prev_candle['low'] and last_candle['close'] > last_candle['open']):
        # Check if rejection happened near support
        near_sup, sup_level = sr_tracker.is_near_support(last_candle['low'])
        near_orb_low = orb_low and abs(last_candle['low'] - orb_low) <= SR_ZONE_TOLERANCE_PTS
        near_session_low = session_low and abs(last_candle['low'] - session_low) <= SR_ZONE_TOLERANCE_PTS
        
        if near_orb_low:
            move_from_low = current_price - last_candle['low']
            if move_from_low >= MIN_REJECTION_MOVE_PTS:
                return 'bullish', f"ORB Low Rejection at {orb_low:.0f} (Hammer)", orb_low
        
        if near_session_low:
            move_from_low = current_price - last_candle['low']
            if move_from_low >= MIN_REJECTION_MOVE_PTS:
                return 'bullish', f"Session Low Rejection at {session_low:.0f}", session_low
        
        if near_sup:
            move_from_low = current_price - last_candle['low']
            if move_from_low >= MIN_REJECTION_MOVE_PTS:
                return 'bullish', f"Support Rejection at {sup_level:.0f}", sup_level
    
    # Check for swing high/low rejections (even without perfect pin bar)
    if len(candles) >= 3:
        # Price made new high but closed weak (bearish rejection)
        if (last_candle['high'] > max(c['high'] for c in candles[-3:-1]) and 
            last_candle['close'] < last_candle['open'] and
            current_price < last_candle['high'] - MIN_REJECTION_MOVE_PTS):
            sr_tracker.add_level(last_candle['high'], 'resistance')
            return 'bearish', f"Swing High Rejection at {last_candle['high']:.0f}", last_candle['high']
        
        # Price made new low but closed strong (bullish rejection)
        if (last_candle['low'] < min(c['low'] for c in candles[-3:-1]) and
            last_candle['close'] > last_candle['open'] and
            current_price > last_candle['low'] + MIN_REJECTION_MOVE_PTS):
            sr_tracker.add_level(last_candle['low'], 'support')
            return 'bullish', f"Swing Low Rejection at {last_candle['low']:.0f}", last_candle['low']
    
    return None, None, None

# ---------- Structure / Trendline (old lightweight logic) ----------

def update_swings(price_history, swing_highs, swing_lows):
    """Detect swing highs/lows using 5-bar lookback (2 left + 1 center + 2 right)
    to avoid micro-noise from 1-minute samples creating false swings.
    """
    idx = len(price_history) - 1
    if idx < 4:  # Need at least 5 bars: 2 left, 1 mid, 2 right
        return
    mid_idx = idx - 2  # Center of the 5-bar window
    left1 = price_history[mid_idx - 2]
    left2 = price_history[mid_idx - 1]
    mid = price_history[mid_idx]
    right1 = price_history[mid_idx + 1]
    right2 = price_history[mid_idx + 2]
    # Swing high: mid is higher than both left bars AND both right bars
    if mid > left1 and mid > left2 and mid > right1 and mid > right2:
        # Require minimum distance from last swing high to avoid clustering
        if not swing_highs or abs(mid - swing_highs[-1][1]) > 10:
            swing_highs.append((mid_idx, mid))
            if len(swing_highs) > 20:
                swing_highs.pop(0)
    # Swing low: mid is lower than both left bars AND both right bars
    if mid < left1 and mid < left2 and mid < right1 and mid < right2:
        # Require minimum distance from last swing low to avoid clustering
        if not swing_lows or abs(mid - swing_lows[-1][1]) > 10:
            swing_lows.append((mid_idx, mid))
            if len(swing_lows) > 20:
                swing_lows.pop(0)


def get_trend_state(swing_highs, swing_lows):
    if len(swing_highs) >= 2 and len(swing_lows) >= 2:
        h1, h2 = swing_highs[-2], swing_highs[-1]
        l1, l2 = swing_lows[-2], swing_lows[-1]
        if h2[1] > h1[1] and l2[1] > l1[1]:
            return 'up'
        if h2[1] < h1[1] and l2[1] < l1[1]:
            return 'down'
    return 'sideways'


def check_trendline_break(trend_state, swing_highs, swing_lows, cur_idx, cur_price):
    if trend_state == 'up' and len(swing_lows) >= 2:
        (i1, p1), (i2, p2) = swing_lows[-2], swing_lows[-1]
        if cur_idx <= i2:
            return None
        slope = (p2 - p1) / max(1, (i2 - i1))
        y = p1 + slope * (cur_idx - i1)
        if cur_price < y * (1 - TRENDLINE_TOL_PCT / 100):
            return 'bearish'
    if trend_state == 'down' and len(swing_highs) >= 2:
        (i1, p1), (i2, p2) = swing_highs[-2], swing_highs[-1]
        if cur_idx <= i2:
            return None
        slope = (p2 - p1) / max(1, (i2 - i1))
        y = p1 + slope * (cur_idx - i1)
        if cur_price > y * (1 + TRENDLINE_TOL_PCT / 100):
            return 'bullish'
    return None

# ---------- Premium message formatting ----------

def format_price(v):
    return f"{float(v):.1f}"

def format_signed_pct(x):
    return "NA" if x is None else f"{x:+.2f}%"

def format_expiry_display(e):
    try:
        return (e if isinstance(e, str) else e.strftime('%d-%b-%Y')).upper()
    except Exception:
        return str(e)


def build_targets(ltp):
    """Build targets using Risk:Reward approach
    SL is fixed % below entry
    Targets are multiples of risk (entry - SL)
    """
    e_low = round(ltp * ENTRY_LOW_PCT, 1)
    e_high = round(ltp * ENTRY_HIGH_PCT, 1)
    buy_above = e_high
    sl = round(ltp * (1 - SL_PCT), 1)  # 15% below LTP
    risk = buy_above - sl
    # Targets based on R:R multiples
    tgts = [round(buy_above + (risk * rr), 1) for rr in TARGET_RR_MULTIPLIERS]
    return e_low, e_high, tgts, sl


# ---------- Supertrend Calculation ----------

def calculate_supertrend(price_history, period=SUPERTREND_PERIOD, multiplier=SUPERTREND_MULTIPLIER):
    """Calculate Supertrend bias with proper state tracking.
    Uses EMA-smoothed ATR and maintains trend direction via band flips.
    Returns: 'Bullish', 'Bearish', or 'Neutral'
    """
    if len(price_history) < period + 1:
        return 'Neutral'
    
    # Calculate ATR using price changes (EMA-smoothed)
    changes = [abs(price_history[i] - price_history[i-1]) for i in range(1, len(price_history))]
    if len(changes) < period:
        return 'Neutral'
    
    # EMA of ATR for smoother bands
    ema_multiplier = 2.0 / (period + 1)
    atr = sum(changes[:period]) / period  # Initial SMA
    for i in range(period, len(changes)):
        atr = changes[i] * ema_multiplier + atr * (1 - ema_multiplier)
    
    if atr < 1:
        return 'Neutral'
    
    # Walk through price history and track supertrend state
    direction = 1  # 1 = bullish, -1 = bearish
    prev_upper = 0
    prev_lower = 0
    
    start = max(period, len(price_history) - 30)  # Look at last 30 bars
    for i in range(start, len(price_history)):
        hl_mid = (price_history[i] + price_history[i-1]) / 2  # Approximate HL/2
        upper_band = hl_mid + (multiplier * atr)
        lower_band = hl_mid - (multiplier * atr)
        
        # Clamp bands (standard supertrend logic)
        if prev_upper > 0:
            upper_band = min(upper_band, prev_upper) if price_history[i-1] <= prev_upper else upper_band
        if prev_lower > 0:
            lower_band = max(lower_band, prev_lower) if price_history[i-1] >= prev_lower else lower_band
        
        # Flip direction
        if price_history[i] > upper_band:
            direction = 1
        elif price_history[i] < lower_band:
            direction = -1
        
        prev_upper = upper_band
        prev_lower = lower_band
    
    return 'Bullish' if direction == 1 else 'Bearish'


def get_dominant_trend(price_history, lookback=DOMINANT_TREND_LOOKBACK):
    """Determine dominant trend over last N price samples.
    Returns: 'bullish', 'bearish', or 'neutral'
    """
    if len(price_history) < lookback:
        return 'neutral'
    
    recent = price_history[-lookback:]
    start_price = recent[0]
    end_price = recent[-1]
    move_pct = ((end_price - start_price) / start_price) * 100
    
    # Also check: how many bars are red vs green
    up_bars = sum(1 for i in range(1, len(recent)) if recent[i] > recent[i-1])
    down_bars = sum(1 for i in range(1, len(recent)) if recent[i] < recent[i-1])
    
    if move_pct >= DOMINANT_TREND_MIN_MOVE_PCT and up_bars > down_bars:
        return 'bullish'
    elif move_pct <= -DOMINANT_TREND_MIN_MOVE_PCT and down_bars > up_bars:
        return 'bearish'
    return 'neutral'


def compute_signal_score(side, reason, trend_state, orb_status, oi_pct_active, oi_pct_other, supertrend_bias='Neutral'):
    score = 40
    if 'Structure Flip' in reason:
        score += 18
    elif 'Trendline Break' in reason:
        score += 15
    elif 'Opening Range' in reason:
        score += 14
    elif 'Early' in reason:
        score += 10
    if side == 'CE':
        if trend_state == 'up':
            score += 12
        elif trend_state == 'sideways':
            score += 5
        if orb_status == 'Above ORB':
            score += 10
        elif orb_status == 'Inside ORB':
            score += 3
        if oi_pct_active is not None:
            if oi_pct_active >= 7:
                score += 12
            elif oi_pct_active >= 3:
                score += 8
            elif oi_pct_active > 0:
                score += 4
        if oi_pct_other is not None and oi_pct_other < 0:
            score += 5
        # Supertrend alignment bonus
        if supertrend_bias == 'Bullish':
            score += 8
    else:
        if trend_state == 'down':
            score += 12
        elif trend_state == 'sideways':
            score += 5
        if orb_status == 'Below ORB':
            score += 10
        elif orb_status == 'Inside ORB':
            score += 3
        if oi_pct_active is not None:
            if oi_pct_active >= 7:
                score += 12
            elif oi_pct_active >= 3:
                score += 8
            elif oi_pct_active > 0:
                score += 4
        if oi_pct_other is not None and oi_pct_other < 0:
            score += 5
        # Supertrend alignment bonus
        if supertrend_bias == 'Bearish':
            score += 8
    return max(0, min(100, int(round(score))))


def build_signal_text(symbol_name, strike, side, ltp, expiry, underlying, reason, trend_state, orb_status,
                      ce_oi_pct, pe_oi_pct, now_ist_str=None, signal_move_pct=None, supertrend_bias='Neutral'):
    e_low, e_high, tgts, sl = build_targets(ltp)
    buy_above = e_high
    risk = buy_above - sl
    rr_t2 = (tgts[1] - buy_above) / risk if risk > 0 else None
    active_oi = ce_oi_pct if side == 'CE' else pe_oi_pct
    other_oi = pe_oi_pct if side == 'CE' else ce_oi_pct
    score = compute_signal_score(side, reason, trend_state, orb_status, active_oi, other_oi, supertrend_bias)

    lines = [
        f"‼️ {symbol_name} {strike} {side} ‼️",
        "",
        f"✅ BUY ABOVE : {format_price(buy_above)}",
        f"📥 ENTRY ZONE : {format_price(e_low)} to {format_price(e_high)}",
        "",
        f"💰 T1 : {format_price(tgts[0])}",
        f"💰 T2 : {format_price(tgts[1])}",
        f"💰 T3 : {format_price(tgts[2])}",
        f"💰 T4 : {format_price(tgts[3])}",
        f"💰 T5 : {format_price(tgts[4])}",
        "",
        f"🛑 SL : {format_price(sl)}",
        "",
        f"📍 Spot : {format_price(underlying)}",
        f"📅 Expiry : {format_expiry_display(expiry)} (Current Week)",
        f"🕒 Time (IST) : {now_ist_str}",
    ]
    if signal_move_pct is not None:
        lines.append(f"⚡ Move % : {signal_move_pct:+.2f}%")
    if rr_t2 is not None:
        lines.append(f"📊 RR (to T2) : {rr_t2:.2f}")
    # Structure label
    struct_label = 'HH-HL (Bullish)' if trend_state == 'up' else ('LH-LL (Bearish)' if trend_state == 'down' else 'Sideways')
    lines.extend([
        f"🧠 Score : {score}/100",
        "",
        "Confirmation:",
        f"• Reason : {reason}",
        f"• Structure : {struct_label}",
        f"• ORB : {orb_status}",
        f"• Supertrend : {supertrend_bias}",
        f"• CE OI : {format_signed_pct(ce_oi_pct)}",
        f"• PE OI : {format_signed_pct(pe_oi_pct)}",
    ])
    return "\n".join(lines)

# ---------- Telegram helpers ----------

def clear_telegram_webhook():
    try:
        requests.post(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/deleteWebhook", timeout=10)
    except Exception:
        pass

def send_telegram(text):
    try:
        r = requests.post(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                          data={"chat_id": TELEGRAM_CHAT_ID, "text": text}, timeout=10)
        if not r.ok:
            # log API error details so diagnosis is easier
            print(f"Telegram API error {r.status_code}: {r.text[:200]}")
    except Exception as e:
        print("Telegram send error:", e)


def send_telegram_with_confirm(text, instrument):
    cb_c = f"CONFIRM_{instrument['tradingsymbol'][:40]}"
    cb_s = f"SKIP_{instrument['tradingsymbol'][:40]}"
    markup = {"inline_keyboard": [[{"text": "Confirm BUY", "callback_data": cb_c}, {"text": "Skip", "callback_data": cb_s}]]}
    try:
        r = requests.post(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                          json={"chat_id": TELEGRAM_CHAT_ID, "text": text + "\n\n-- Confirm to place order --", "reply_markup": json.dumps(markup)}, timeout=10)
        if not r.ok:
            print(f"Telegram confirm API error {r.status_code}: {r.text[:200]}")
            return None
        data = r.json()
        return data.get('result', {}).get('message_id') if data.get('ok') else None
    except Exception as e:
        print("Telegram confirm send exception:", e)
        return None

def wait_for_telegram_confirmation(message_id, timeout_sec=CONFIRM_TIMEOUT_SEC):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getUpdates"
    answer = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/answerCallbackQuery"
    start = time.time()
    last_id = 0
    while time.time() - start < timeout_sec:
        try:
            params = {"timeout": 5, "allowed_updates": ["callback_query"]}
            if last_id:
                params['offset'] = last_id + 1
            resp = requests.get(url, params=params, timeout=15).json()
            for u in resp.get('result', []):
                last_id = u['update_id']
                cb = u.get('callback_query')
                if cb and cb.get('message', {}).get('message_id') == message_id:
                    try:
                        requests.post(answer, json={"callback_query_id": cb['id'], "text": "Received!"}, timeout=5)
                    except Exception:
                        pass
                    return 'CONFIRM' if cb.get('data', '').startswith('CONFIRM') else 'SKIP'
        except Exception:
            pass
        time.sleep(2)
    return 'TIMEOUT'

def edit_telegram_message(message_id, new_text):
    try:
        requests.post(f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/editMessageText",
                      json={"chat_id": TELEGRAM_CHAT_ID, "message_id": message_id, "text": new_text}, timeout=10)
    except Exception:
        pass

# ---------- Order ----------

def place_kite_order(inst, transaction_type='BUY', price=None):
    """Place order on BFO exchange for Sensex options"""
    qty = inst['lot_size'] * ORDER_QUANTITY_LOTS
    try:
        kwargs = dict(
            variety=kite.VARIETY_REGULAR,
            exchange=kite.EXCHANGE_BFO,  # BSE F&O exchange
            tradingsymbol=inst['tradingsymbol'],
            transaction_type=transaction_type,
            quantity=qty,
            product=PRODUCT_TYPE,
            order_type=ORDER_TYPE,
            validity=kite.VALIDITY_DAY,
            tag='SensexScannerLite'
        )
        if ORDER_TYPE == 'LIMIT' and price is not None:
            kwargs['price'] = price
        oid = kite.place_order(**kwargs)
        return {"success": True, "order_id": oid}
    except Exception as e:
        return {"success": False, "error": str(e)}

# ---------- MAIN LOOP ----------

def main():
    print("Starting SENSEX scanner V1.0 — Intraday Momentum + Premium Alerts (BFO)")

    if TEST_ALERT:
        now_ist = fmt_ist_now()
        # Dummy instrument structure for test path
        dummy_inst = {'tradingsymbol': 'SENSEX26MAR77000CE', 'lot_size': sensex_lot_size}
        sample = build_signal_text('SENSEX', 77000, 'CE', 180.0, date.today(), 77125.5,
                                   'Script + Telegram OK', 'up', 'Above ORB', 3.4, -2.2, now_ist)
        msg_id = send_telegram_with_confirm(sample, dummy_inst)
        if msg_id:
            edit_telegram_message(msg_id, sample + "\n\n-- TEST COMPLETE --")
        else:
            send_telegram(sample)
        return

    # Login & load instruments
    kite_login()
    load_sensex_instruments()
    clear_telegram_webhook()

    expiry_date = get_current_week_expiry()
    if not expiry_date:
        print('No nearest expiry found; exiting.')
        return

    # State for signals & OI
    price_history = []
    swing_highs = []
    swing_lows = []
    trend_state = 'sideways'
    bar_index = 0

    # Reference range captured during 9:15–9:30
    opening_ref_high = None
    opening_ref_low = None
    ref_recording = True  # still within first-15min

    # Per-instrument base/previous OI and dedupe keys
    base_oi = {}  # key: BFO:<tsymbol> -> first-seen OI (baseline for % change calc)
    prev_oi = {}  # key: BFO:<tsymbol> -> prev_oi
    sent_keys = set()  # (expiry|side|strike)

    opening_range_high = None
    opening_range_low = None
    orb_alert_sent = False
    breakout_done = False
    breakdown_done = False
    
    # Supertrend state
    supertrend_bias = 'Neutral'
    
    # S/R Rejection tracking
    candle_tracker = CandleTracker(interval_minutes=3)
    sr_tracker = SRLevelTracker()
    last_rejection_time = None  # Avoid duplicate rejection signals
    
    # Signal direction tracking (prevents opposite direction whipsaw)
    last_signal_direction = None  # 'CE' or 'PE'
    last_signal_time = None

    while True:
        now = datetime.now()
        t = now.time()
        # Market hours gate
        if not within_market_time():
            print("Not in market hours. Sleeping 60s…")
            time.sleep(60)
            continue

        # Refresh expiry if needed
        if expiry_date < _date.today():
            load_sensex_instruments()
            expiry_date = get_current_week_expiry()
            opening_range_high = None
            opening_range_low = None
            breakout_done = False
            breakdown_done = False

        # Spot - Get SENSEX from BSE
        try:
            spot_data = kite.ltp(["BSE:SENSEX"])['BSE:SENSEX']
            underlying = spot_data['last_price']
        except Exception as e:
            print("Failed to get SENSEX spot:", e)
            time.sleep(INTERVAL_SEC)
            continue

        # record reference range during initial 9:15-9:30
        if t >= dtime(9, 15) and t <= dtime(9, 30):
            if opening_ref_high is None or underlying > opening_ref_high:
                opening_ref_high = underlying
            if opening_ref_low is None or underlying < opening_ref_low:
                opening_ref_low = underlying
        elif ref_recording and t > dtime(9, 30):
            ref_recording = False
            if opening_ref_high is None or opening_ref_low is None:
                # started after the normal window; use current price as both bounds
                opening_ref_high = opening_ref_low = underlying
                print(f"Started after 9:30; using current price {underlying:.1f} as reference")
            else:
                print(f"Captured reference high={opening_ref_high:.1f}, low={opening_ref_low:.1f}")

        # Map CE/PE ATM+OTM instruments
        maps = find_instruments_for_offsets(underlying, expiry_date, ALERT_OFFSETS)
        if len(maps['CE']) < len(ALERT_OFFSETS) or len(maps['PE']) < len(ALERT_OFFSETS):
            # If some instrument missing (near strikes not listed yet), reload instruments once
            load_sensex_instruments()
            maps = find_instruments_for_offsets(underlying, expiry_date, ALERT_OFFSETS)
            if len(maps['CE']) == 0 or len(maps['PE']) == 0:
                print("ATM/OTM instruments not found this cycle; sleeping…")
                time.sleep(INTERVAL_SEC)
                continue

        # Quotes for all four instruments (BFO exchange)
        quotes = fetch_all_quotes(maps['CE'], maps['PE'])
        if not quotes:
            print("quote() returned empty; sleeping…")
            time.sleep(INTERVAL_SEC)
            continue

        # Compute OI deltas per instrument (from BASELINE, not previous cycle)
        ce_oi_pct_by_off = {}
        pe_oi_pct_by_off = {}
        ce_ltp_by_off = {}
        pe_ltp_by_off = {}

        for off, inst in maps['CE'].items():
            key = f"BFO:{inst['tradingsymbol']}"
            q = quotes.get(key, {})
            ce_ltp_by_off[off] = q.get('ltp')
            cur_oi = q.get('oi')
            # Store baseline OI on first observation
            if key not in base_oi and cur_oi is not None:
                base_oi[key] = cur_oi
            # Calculate OI % change from baseline (not from previous cycle)
            ce_oi_pct_by_off[off] = calc_oi_change_pct(cur_oi, base_oi.get(key))
            prev_oi[key] = cur_oi

        for off, inst in maps['PE'].items():
            key = f"BFO:{inst['tradingsymbol']}"
            q = quotes.get(key, {})
            pe_ltp_by_off[off] = q.get('ltp')
            cur_oi = q.get('oi')
            # Store baseline OI on first observation
            if key not in base_oi and cur_oi is not None:
                base_oi[key] = cur_oi
            # Calculate OI % change from baseline (not from previous cycle)
            pe_oi_pct_by_off[off] = calc_oi_change_pct(cur_oi, base_oi.get(key))
            prev_oi[key] = cur_oi

        # Update swings / trend
        price_history.append(underlying)
        bar_index += 1
        prev_ts = trend_state
        if len(price_history) >= 3:
            update_swings(price_history, swing_highs, swing_lows)
            trend_state = get_trend_state(swing_highs, swing_lows)

        # Use swing-based structure as primary trend.
        # Reference range only serves as a tie-breaker when structure is sideways.
        if not ref_recording and opening_ref_high is not None and opening_ref_low is not None:
            if trend_state == 'sideways':  # Only override when structure is unclear
                if underlying > opening_ref_high:
                    trend_state = 'up'
                elif underlying < opening_ref_low:
                    trend_state = 'down'
        tl_break = check_trendline_break(prev_ts, swing_highs, swing_lows, bar_index - 1, underlying)

        # ORB
        if t <= dtime(10, 0):
            if opening_range_high is None or underlying > opening_range_high:
                opening_range_high = underlying
            if opening_range_low is None or underlying < opening_range_low:
                opening_range_low = underlying
        
        # ORB Status - Always show Above/Below/Inside ORB (not "Building ORB")
        if opening_range_high is None or opening_range_low is None:
            orb_status = "Awaiting ORB"
        elif underlying > opening_range_high:
            orb_status = "Above ORB"
        elif underlying < opening_range_low:
            orb_status = "Below ORB"
        else:
            orb_status = "Inside ORB"
        
        # Calculate Supertrend bias
        supertrend_bias = calculate_supertrend(price_history)
        
        # Update candle tracker for OHLC pattern detection
        candle_tracker.update(underlying)

        # Send ORB capture alert once after range is established
        if not orb_alert_sent and opening_range_high is not None and opening_range_low is not None and t > dtime(9, 30):
            orb_alert_sent = True
            orb_range = opening_range_high - opening_range_low
            orb_text = (
                f"SENSEX ORB CAPTURED\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"High: {opening_range_high:.2f}\n"
                f"Low:  {opening_range_low:.2f}\n"
                f"Range: {orb_range:.2f} pts\n"
                f"Spot:  {underlying:.2f}\n"
                f"Time: {fmt_ist_now()}"
            )
            send_telegram(orb_text)

        # Decide signals (bearish / bullish) once per cycle, then fan out to ATM+OTM for that side
        signal_bearish = None
        signal_bullish = None
        # structure flip
        if prev_ts in ('up', 'down') and trend_state in ('up', 'down') and prev_ts != trend_state:
            if trend_state == 'down':
                signal_bearish = "Structure Flip HH-HL -> LH-LL (Downtrend)"
            else:
                signal_bullish = "Structure Flip LH-LL -> HH-HL (Uptrend)"
        # trendline breaks
        if signal_bearish is None and tl_break == 'bearish':
            signal_bearish = "Trendline Break from Uptrend (swing-low line broken)"
        if signal_bullish is None and tl_break == 'bullish':
            signal_bullish = "Trendline Break from Downtrend (swing-high line broken)"
        # S/R REJECTION DETECTION (Priority signal for trend reversals)
        # This catches rejections at key levels like session high/low, ORB levels
        current_time = datetime.now()
        sr_signal, sr_reason, sr_level = check_sr_rejection(
            candle_tracker, sr_tracker, underlying, opening_range_high, opening_range_low
        )
        
        # Avoid duplicate rejection signals within 3 minutes
        can_send_rejection = (last_rejection_time is None or 
                              (current_time - last_rejection_time).total_seconds() > 180)
        
        if sr_signal and can_send_rejection:
            if sr_signal == 'bearish' and signal_bearish is None:
                signal_bearish = sr_reason
                last_rejection_time = current_time
                print(f"S/R REJECTION DETECTED: {sr_reason} at {fmt_ist_now()}")
            elif sr_signal == 'bullish' and signal_bullish is None:
                signal_bullish = sr_reason
                last_rejection_time = current_time
                print(f"S/R REJECTION DETECTED: {sr_reason} at {fmt_ist_now()}")
        
        # early reversal (fallback if no S/R rejection)
        if len(price_history) >= 3:
            prev_underlying = price_history[-3]
            last_underlying = price_history[-2]
            if signal_bearish is None and last_underlying >= prev_underlying and underlying < last_underlying:
                drop_pct = (underlying - last_underlying) / last_underlying * 100
                # require option LTP to be holding vs last sample for stability (ATM CE/PE ltp exist)
                if abs(drop_pct) >= PA_MIN_MOVE_PCT:
                    signal_bearish = f"Early Downtrend Turn (3m red reversal bar)"
            if signal_bullish is None and last_underlying <= prev_underlying and underlying > last_underlying:
                rise_pct = (underlying - last_underlying) / last_underlying * 100
                if abs(rise_pct) >= PA_MIN_MOVE_PCT:
                    signal_bullish = f"Early Uptrend Turn (3m green reversal bar)"
        # ORB
        if orb_status == "Above ORB" and signal_bullish is None:
            signal_bullish = "Opening Range Breakout"
        if orb_status == "Below ORB" and signal_bearish is None:
            signal_bearish = "Opening Range Breakdown"

        # DOMINANT TREND FILTER — Suppress counter-trend signals
        dominant = get_dominant_trend(price_history)
        
        if signal_bullish and dominant == 'bearish':
            # In a dominant downtrend, suppress CE signals unless it's a strong S/R rejection
            if 'Rejection' not in (signal_bullish or '') and 'Structure Flip' not in (signal_bullish or ''):
                print(f"TREND FILTER: Suppressing CE signal '{signal_bullish}' — dominant trend is bearish")
                signal_bullish = None
        
        if signal_bearish and dominant == 'bullish':
            # In a dominant uptrend, suppress PE signals unless it's a strong S/R rejection
            if 'Rejection' not in (signal_bearish or '') and 'Structure Flip' not in (signal_bearish or ''):
                print(f"TREND FILTER: Suppressing PE signal '{signal_bearish}' — dominant trend is bullish")
                signal_bearish = None

        # TREND ALIGNMENT CHECK — Prevent contradictory Structure + Signal
        # Don't send CE when structure is bearish, or PE when structure is bullish
        if signal_bullish and trend_state == 'down' and supertrend_bias == 'Bearish':
            print(f"ALIGNMENT BLOCK: Suppressing CE signal — structure is LH-LL (Bearish) + Supertrend Bearish")
            signal_bullish = None
        if signal_bearish and trend_state == 'up' and supertrend_bias == 'Bullish':
            print(f"ALIGNMENT BLOCK: Suppressing PE signal — structure is HH-HL (Bullish) + Supertrend Bullish")
            signal_bearish = None

        # OPPOSITE SIGNAL COOLDOWN CHECK
        # Prevents whipsaw signals (PE then CE, or CE then PE) in sideways/range-bound markets
        current_time = datetime.now()
        
        if last_signal_time is not None:
            time_since_last = (current_time - last_signal_time).total_seconds()
            
            # Check if trying to send opposite direction signal too soon
            if signal_bullish and last_signal_direction == 'PE':
                if time_since_last < OPPOSITE_SIGNAL_COOLDOWN_SEC:
                    print(f"COOLDOWN: Suppressing CE signal - only {time_since_last:.0f}s since last PE signal (need {OPPOSITE_SIGNAL_COOLDOWN_SEC}s)")
                    signal_bullish = None
            
            if signal_bearish and last_signal_direction == 'CE':
                if time_since_last < OPPOSITE_SIGNAL_COOLDOWN_SEC:
                    print(f"COOLDOWN: Suppressing PE signal - only {time_since_last:.0f}s since last CE signal (need {OPPOSITE_SIGNAL_COOLDOWN_SEC}s)")
                    signal_bearish = None
            
            # Also apply cooldown for same direction signals
            if signal_bullish and last_signal_direction == 'CE':
                if time_since_last < SAME_DIRECTION_COOLDOWN_SEC:
                    print(f"COOLDOWN: Suppressing CE signal - only {time_since_last:.0f}s since last CE signal (need {SAME_DIRECTION_COOLDOWN_SEC}s)")
                    signal_bullish = None
            
            if signal_bearish and last_signal_direction == 'PE':
                if time_since_last < SAME_DIRECTION_COOLDOWN_SEC:
                    print(f"COOLDOWN: Suppressing PE signal - only {time_since_last:.0f}s since last PE signal (need {SAME_DIRECTION_COOLDOWN_SEC}s)")
                    signal_bearish = None

        # debug logging for signal decisions
        if signal_bearish or signal_bullish:
            print(f"Signal decision at {fmt_ist_now()}: underlying={underlying:.1f}, trend={trend_state}, orb={orb_status}, bearish={signal_bearish}, bullish={signal_bullish}")
        else:
            # optional log every 10 cycles to confirm working
            if bar_index % 10 == 0:
                print(f"No signal this cycle (bar {bar_index}) – trend={trend_state}, orb={orb_status}")

        # Build & send alerts: up to 2 strikes per active side
        now_ist = fmt_ist_now()

        def maybe_send(side, reason, ltp_map, oi_pct_map, other_oi_pct_map):
            # side: 'CE' or 'PE'
            # Iterate offsets in ALERT_OFFSETS order; send for each if data present
            count = 0
            for off in ALERT_OFFSETS:
                inst = maps[side].get(off)
                if not inst:
                    print(f"maybe_send: missing instrument for side={side} offset={off}")
                    continue
                key = f"BFO:{inst['tradingsymbol']}"
                ltp = ltp_map.get(off)
                if ltp is None:  # skip if no ltp
                    print(f"maybe_send: no LTP for {key}")
                    continue
                active_oi = oi_pct_map.get(off)
                other_oi = None
                # Derive other side oi at same off when available
                if side == 'CE':
                    other_oi = other_oi_pct_map.get(off)
                else:
                    other_oi = other_oi_pct_map.get(off)
                # Optional OI filter
                if OI_FILTER_ENABLED and active_oi is not None and active_oi < OI_MIN_BUILD_PCT:
                    print(f"maybe_send: OI filter blocked {key} pct={active_oi}")
                    continue
                strike = int(inst['strike'])
                dedupe = f"{expiry_date}|{side}|{strike}"
                if dedupe in sent_keys:
                    # Already sent earlier in the session for this strike/side/expiry
                    print(f"maybe_send: already sent {dedupe}, skipping")
                    continue
                # Get correct OI percentages for both CE and PE
                ce_oi_pct_val = ce_oi_pct_by_off.get(off)
                pe_oi_pct_val = pe_oi_pct_by_off.get(off)
                
                # Pre-check score before sending — skip low-confidence signals
                pre_score = compute_signal_score(side, reason, trend_state, orb_status,
                                                active_oi, other_oi, supertrend_bias)
                if pre_score < MIN_SCORE_TO_SEND:
                    print(f"maybe_send: score {pre_score} < {MIN_SCORE_TO_SEND} for {key}, skipping weak signal")
                    continue
                
                text = build_signal_text('SENSEX', strike, side, ltp, expiry_date, underlying,
                                         reason, trend_state, orb_status,
                                         ce_oi_pct=ce_oi_pct_val,
                                         pe_oi_pct=pe_oi_pct_val,
                                         now_ist_str=now_ist,
                                         supertrend_bias=supertrend_bias)
                # Send
                if SEMI_AUTO_ENABLED:
                    msg_id = send_telegram_with_confirm(text, inst)
                    if msg_id is None:
                        send_telegram(text)
                    else:
                        # Wait for confirmation
                        res = wait_for_telegram_confirmation(msg_id, CONFIRM_TIMEOUT_SEC)
                        if res == 'CONFIRM':
                            price_param = ltp if ORDER_TYPE == 'LIMIT' else None
                            ord_res = place_kite_order(inst, 'BUY', price=price_param)
                            if ord_res['success']:
                                edit_telegram_message(msg_id, text + f"\n\nORDER PLACED\nOrder ID: {ord_res['order_id']}")
                            else:
                                edit_telegram_message(msg_id, text + f"\n\nORDER FAILED: {ord_res['error']}")
                        elif res == 'SKIP':
                            edit_telegram_message(msg_id, text + "\n\n-- SKIPPED by user --")
                        else:
                            edit_telegram_message(msg_id, text + "\n\n-- TIMED OUT (no response) --")
                else:
                    send_telegram(text)
                sent_keys.add(dedupe)
                count += 1
                if count >= len(ALERT_OFFSETS):
                    break

        # Decide which sides to send
        if signal_bullish:
            # CE side
            maybe_send('CE', signal_bullish, ce_ltp_by_off, ce_oi_pct_by_off, pe_oi_pct_by_off)
            # Update signal tracking
            last_signal_direction = 'CE'
            last_signal_time = datetime.now()
        if signal_bearish:
            # PE side
            maybe_send('PE', signal_bearish, pe_ltp_by_off, pe_oi_pct_by_off, ce_oi_pct_by_off)
            # Update signal tracking
            last_signal_direction = 'PE'
            last_signal_time = datetime.now()

        # Heartbeat log
        # Show ATM info (offset 0) to keep console active & helpful
        ce0 = maps['CE'].get(0)
        pe0 = maps['PE'].get(0)
        ce0_ltp = ce_ltp_by_off.get(0)
        pe0_ltp = pe_ltp_by_off.get(0)
        ce0_oi = ce_oi_pct_by_off.get(0)
        pe0_oi = pe_oi_pct_by_off.get(0)
        # Get session high/low for display
        sess_high, sess_low = candle_tracker.get_session_high_low()
        dominant = get_dominant_trend(price_history)
        sess_info = f"SH={sess_high:.0f} SL={sess_low:.0f}" if sess_high else "S/R building"
        print(f"[HB] {fmt_ist_now()} | SENSEX={underlying:.1f} | {sess_info} | Trend={trend_state} Dom={dominant} ST={supertrend_bias} | CE {ce0['strike'] if ce0 else '-'} LTP={ce0_ltp} OI%={format_signed_pct(ce0_oi)} | PE {pe0['strike'] if pe0 else '-'} LTP={pe0_ltp} OI%={format_signed_pct(pe0_oi)} | ORB={orb_status}")

        time.sleep(INTERVAL_SEC)

if __name__ == '__main__':
    main()
